import {useEffect, useState, useRef} from 'react';
import './App.css';
import ScreenPokemones from './components/ScreenPokemones';
import pokemonImage from '../public/pokemon.png';
import pokefont from '../public/pokefont.ttf'
import Battlescreen from './components/Battlescreen';
import GameOverScreen from './components/GameOverScreen';
import fight from '../public/pokemon-battle.mp3'
import theme from '../public/oaklab.mp3'

function App() {
  <audio id = "theme" src="../public/oaklab.mp3"></audio>
  const [pokemones, setPokemones] = useState('');
  const [position, setPosition] = useState(0);

  const [myPokeSelection, setMyPokeSelection] = useState([]);
  const [computerRandomSelection, setcomputerRandomSelection] = useState([]);

  const [startGame, setStartGame] = useState(false);

  const [myHealth, setMyHealth] = useState(100);

  const [enemyHealth, setEnemyHp] = useState(100);

  const [gameOver, setGameOver] = useState(false);

  const soundRef = useRef(null);

  const oaktheme = document.getElementById('theme')

  const pokeUrl = 'https://pokeapi.co/api/v2/pokemon';

  const fetchData = async (url) => {
    const response = await fetch(url);
    const data = await response.json();
    return data;
  };

  const pokemonData = async (pokeUrl) => {
    const response = await fetchData(pokeUrl);

    const dataPromises = response.results.map((poke) =>
      fetchData(pokeUrl + '/' + poke.name)
    );

    // console.log(dataPromises);
    const pokemonWithImages = await Promise.all(dataPromises);

    const addAttack = pokemonWithImages.map((pokemon) => {
      const attackValue = pokemon.moves.map((move) => ({
        ...move,
        attack: Math.floor(Math.random() * 50),
      }));

      return { ...pokemon, moves: attackValue };
    });

    console.log(addAttack);
    setPokemones(addAttack);
    // console.log(pokemonWithImages);
  };

  const handleSelection = (Foward) => {

    console.log(Foward);
    if(!Foward && position <= 0) return;
    if(Foward && position >= 19) return;
    if(!Foward) {
      setPosition(position - 1)
    } else {
      setPosition(position + 1)
    }

    //console.log(position);
  } 

  const handleAttack = () => {
    const myAttack = Math.floor(Math.random() * 30);
    const enemyAttackDmg = Math.floor(Math.random() * 30);

    setEnemyHp(enemyHealth-myAttack);
    setMyHealth(myHealth-enemyAttackDmg);
  }

  const filterSelection = () => {
    const mySelection = pokemones.filter((value, idx) => position === idx);
    setMyPokeSelection(mySelection);
    console.log(mySelection);

    getcomputerSelection();
  };

  const getcomputerSelection = () => {
    const computerPos = Math.floor(Math.random() * 20);
    const computerSelection = pokemones.filter((value, idx) => computerPos === idx);
    setcomputerRandomSelection(computerSelection);
    console.log(computerSelection);
  }

  const handleStart = () => {
    console.log('start');
    setStartGame(true);
    soundRef.current.play();
    oaktheme.pause();
  }

  useEffect(() => {
    pokemonData(pokeUrl);
  }, []);

  const restartGame = () => {
    if (soundRef.current !== null) {
      soundRef.current.pause();
      soundRef.current.currentTime = 0; 
    }

    setGameOver(false);
    setMyHealth(100);
    setEnemyHp(100);
    setStartGame(false);
  };

  useEffect(() => {
    if (myHealth <= 0) {
      setGameOver('lost');
    } else if (enemyHealth <= 0) {
      setGameOver('won');
    }
  }, [myHealth, enemyHealth]);
  
  return (
    <>
      <div className='wrapper'></div>
      <div className="main-container">
        <img src={pokemonImage} alt = "Pokemon" id = 'pokeimg'/>
          
        {/* screen */}

        <div className="layout-game">
          <div className="container-screen">
            <div className="screen-layout">
              <div className="screen-layout2">
                {gameOver ? (
                  <GameOverScreen gameOver={gameOver} restartGame={restartGame} />
                ) : (
                  startGame ? ( 
                    <Battlescreen myPokeSelection={myPokeSelection} computerRandomSelection={computerRandomSelection} myHealth={myHealth} enemyHealth={enemyHealth}/>
                  ) : (
                    pokemones && <ScreenPokemones pokemones={pokemones} position={position} />
                  )
                )}             
              </div>
            </div>
          </div>
          <div className="buttons-container">

            {/* buttons pad*/}

            <div className="container-pad">
              <button 
              className="btn-right-left"
              onClick={() => handleSelection(false)}>
              </button>
              <div className="container-up-down">
                <button className="btn-up"></button>
                <button className="btn-down"></button>
              </div>
              <button 
              className="btn-right-left" 
              onClick={() => handleSelection(true)}>
              </button>
            </div>

            {/* buttons select */}

            <div className="container-select">
              <div className="container-select-btn">
                <button className="btn-select" onClick={() => filterSelection()}></button>
                <br></br>
                <div>select</div>
              </div>
              <div className="container-start">
                <button className="btn-start" onClick={() => handleStart() }></button>
                <audio ref={soundRef} id="fight" src="../public/pokemon-battle.mp3"></audio>
                <br></br>
                <div>start</div>
              </div>
            </div>

            {/* buttons actions */}

            <div className="container-action">
              <div className="button-b-container">
                <button className="button-b"></button>
                <div>B</div>
              </div>
              <div className="button-a-container">
                <button className="button-a" onClick={() => handleAttack()}></button>
                <div>A</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
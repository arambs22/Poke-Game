import './GameOverScreen.css';

const GameOverScreen = ({ gameOver, restartGame }) => {
  const handleRestart = () => {
    restartGame();
  };

  return (
    <div className="game-over-container">
      {gameOver === 'lost' ? (
        <p>GAME OVER</p>
      ) : gameOver === 'won' ? (
        <p>YOU WIN!</p>
      ) : (
        <p></p>
      )}
      <button onClick={handleRestart}>Restart</button>
    </div>
  );
};

export default GameOverScreen;
import './Battlescreen.css';

const BattleScreen = ({ myPokeSelection, computerRandomSelection , myHealth, enemyHealth}) => {
    console.log({myPokeSelection});
    console.log({computerRandomSelection});
    console.log({myHealth});
    console.log({enemyHealth});
    if (!myPokeSelection || !computerRandomSelection) return null;
    return (
        <div className="battle-container">
            <div className="enemy-container">
                <p className='enemy-health' style = {{borderRadius: '5px'}}>HP {enemyHealth}</p>
                <img src={computerRandomSelection[0].sprites.front_default} alt="enemy pokemon" id='enemy'/>  
            </div>
            <div className="my-container">
                <img src={myPokeSelection[0].sprites.back_default} alt="my pokemon" id = 'me'/>
                <p className='my-health' style = {{borderRadius: '5px'}}>HP {myHealth}</p>
            </div>
        </div> 
    )
}

export default BattleScreen;